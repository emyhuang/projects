Emy Huang
emyhuang@usc.edu
Assignment 1
To run, execute Main.java.
Includes 11 classes:
Assistant
Courses
courseStaff
Department
Main
Meeting
MeetingPeriod
Name
Parser
School
Time


