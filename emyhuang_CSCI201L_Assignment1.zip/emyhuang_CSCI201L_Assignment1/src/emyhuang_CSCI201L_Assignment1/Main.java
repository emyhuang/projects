package emyhuang_CSCI201L_Assignment1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import com.google.gson.Gson;

public class Main {
	private static Parser data;
	public static void main(String[] args) {
		Boolean invalidFile;
		Scanner scan = new Scanner(System.in);
		do {
			invalidFile=false;
			System.out.print("Enter the input filename: ");
			String inputFilename = scan.nextLine();
			Gson gson = new Gson();
			try {
				BufferedReader br = new BufferedReader(new FileReader(inputFilename));
				data = gson.fromJson(br, Parser.class);
				/*Checking for validity*/
				if(!data.hasAtLeastOneSchool()) {
					invalidFile = true;
				}
				for(School sch: data.getSchools()) {
					if(!sch.validSchool()) {
						System.out.println("That file is not a well-formed JSON file.");
						System.out.println();
						invalidFile = true;
						break;
					}
					for(Department dept : sch.getDepartments()) {
						if(!dept.isValidDepartment()) {
							System.out.println("That file is not a well-formed JSON file.");
							System.out.println();
							invalidFile = true;
							break;
						}
						for(Courses course : dept.getCourses()) {
							if(!course.isValidCourse()) {
								System.out.println("That file is not a well-formed JSON file.");
								System.out.println();
								invalidFile = true;
								break;
							}
							for(courseStaff cs : course.getStaffMembers()) {
								if(!cs.isCourseStaffValid()) {
									System.out.println("That file is not a well-formed JSON file.");
									System.out.println();
									invalidFile = true;
									break;
								}
							}
							for(Meeting meet : course.getMeetings()) {
								if(!meet.isMeetingValid()) {
									System.out.println("That file is not a well-formed JSON file.");
									System.out.println();
									invalidFile = true;
									break;
								}
							}
						}
					}

				}
				br.close();
			}catch(IOException e) {
				System.out.println("That file could not be found.");
				System.out.println();
				invalidFile = !invalidFile;
			}
		}while(invalidFile);
		String menuOption;

		do {
			System.out.println();
			System.out.println("\t"+ "1) Display Schools");
			System.out.println("\t"+ "2) Exit");
			System.out.print("What would you like to do? ");
			menuOption = scan.nextLine();
			if(menuOption.equals("2")) {
				menuOption = "Exit";
				break;
			}
			int schoolSize = data.getSchools().size();

			try {
				if(!menuOption.equals("1")) {
					throw new NumberFormatException();
				}

				do {
					System.out.println();
					System.out.println("Schools");
					for(int i = 1; i < schoolSize+1; i++ ) {
						System.out.println("\t" + i+") "+ data.getSchools().get(i-1).getName());
					}
					System.out.println("\t"+ Integer.toString(schoolSize+1) + ") Go to main menu");
					System.out.println("\t"+ Integer.toString(schoolSize+2) + ") Exit");
					System.out.print("What would you like to do? ");
					menuOption = scan.nextLine();
					if(menuOption.equals(Integer.toString(schoolSize+1))) {
						break;
					}
					if(menuOption.equals(Integer.toString(schoolSize+2))) {
						menuOption = "Exit";
						break;
					}
					try {
						if(Integer.parseInt(menuOption)<= 0 || Integer.parseInt(menuOption) > schoolSize) {
							throw new NumberFormatException();
						}

						School choiceSchool = data.getSchools().get(Integer.parseInt(menuOption)-1);
						int depSize = choiceSchool.getDepartments().size();
						do {
							System.out.println();
							System.out.println("Departments");
							for(int i = 1; i< depSize+1; i++ ) {
								Department tempDep = choiceSchool.getDepartments().get(i-1);
								System.out.println("\t"+ i +") "+ tempDep.getName()+" ("+tempDep.getPrefix()+")");
							}
							System.out.println("\t"+ Integer.toString(depSize+1) + ") Go to Schools menu");
							System.out.println("\t"+ Integer.toString(depSize+2) + ") Exit");
							System.out.print("What would you like to do? ");
							menuOption = scan.nextLine();

							if(menuOption.equals(Integer.toString(depSize+1))) {
								break;
							}
							if(menuOption.equals(Integer.toString(depSize+2))) {
								menuOption = "Exit";
								break;
							}
							try {
								if(Integer.parseInt(menuOption)<= 0 || Integer.parseInt(menuOption) > depSize) {
									throw new NumberFormatException();
								}

								Department choiceDep = choiceSchool.getDepartments().get(Integer.parseInt(menuOption)-1);
								int courseSize = choiceDep.getCourses().size();
								do {
									System.out.println();
									System.out.println(choiceDep.getPrefix()+ " Courses");
									for(int i = 1; i< courseSize+1; i++ ) {
										Courses tempCo = choiceDep.getCourses().get(i-1);
										System.out.println("\t"+ i +") "+ choiceDep.getPrefix() +" "+ tempCo.getNumber()+" "+ tempCo.getTerm()+" "+ tempCo.getYear());
									}
									System.out.println("\t"+ Integer.toString(courseSize+1) + ") Go to Departments menu");
									System.out.println("\t"+ Integer.toString(courseSize+2) + ") Exit");
									System.out.print("What would you like to do? ");
									menuOption = scan.nextLine();

									if(menuOption.equals(Integer.toString(courseSize+1))) {
										break;
									}
									if(menuOption.equals(Integer.toString(courseSize+2))) {
										menuOption = "Exit";
										break;
									}
									try {
										if(Integer.parseInt(menuOption)<= 0 || Integer.parseInt(menuOption) > courseSize) {
											throw new NumberFormatException();
										}
										String saveMenuOptionCourse = menuOption;
										do {
											System.out.println();
											Courses choiceCourse = choiceDep.getCourses().get(Integer.parseInt(saveMenuOptionCourse)-1);
											System.out.println(choiceDep.getPrefix()+" "+choiceCourse.getNumber()+" "+choiceCourse.getTerm()+" "+choiceCourse.getYear());
											System.out.println("\t"+ "1) View course staff");
											System.out.println("\t"+ "2) View meeting information");
											System.out.println("\t" + "3) Go to "+ choiceDep.getPrefix()+" Courses menu");
											System.out.println("\t" + "4) Exit");
											System.out.print("What would you like to do? ");
											menuOption = scan.nextLine();
											if(menuOption.equals("3")) {
												break;
											}	
											if(menuOption.equals("4")) {
												menuOption = "Exit";
												break;
											}										
											try {
												if(Integer.parseInt(menuOption)<= 0 || Integer.parseInt(menuOption) > 4) {
													throw new NumberFormatException();
												}
												if(menuOption.equals("1")){
													/*read courseStaff*/
													do {
														System.out.println();
														System.out.println(choiceDep.getPrefix()+" "+choiceCourse.getNumber()+" "+choiceCourse.getTerm()+" "+choiceCourse.getYear());
														System.out.println("Course Staff");
														System.out.println("\t"+ "1) View Instructors");
														System.out.println("\t"+ "2) View TAs");
														System.out.println("\t" + "3) View CPs");
														System.out.println("\t" + "4) View Graders");
														System.out.println("\t" + "5) Go to "+choiceDep.getPrefix()+" "+choiceCourse.getNumber()+" "+choiceCourse.getTerm()+" "+choiceCourse.getYear()+ " menu");
														System.out.println("\t"+"6) Exit");
														System.out.print("What would you like to do? ");
														menuOption = scan.nextLine();
														if(menuOption.equals("5")) {
															break;
														}	
														if(menuOption.equals("6")) {
															menuOption = "Exit";
															break;
														}
														try {
															if(Integer.parseInt(menuOption)<= 0 || Integer.parseInt(menuOption) > 6) {
																throw new NumberFormatException();
															}
															int staffSize = choiceCourse.getStaffMembers().size();
															if(menuOption.equals("1") ){

																ArrayList<courseStaff> instructors = choiceCourse.getStaffMembers();
																for(int i=1; i<staffSize+1;i++) {
																	if(instructors.get(i-1).getType().equals("instructor")){
																		System.out.println();
																		System.out.println("Instructor");
																		courseStaff staff = instructors.get(i-1);
																		System.out.println("Name: "+staff.getName().getFirstname()+" "+staff.getName().getLastname());
																		if(staff.getEmail()!=null) {
																			System.out.println("Email: "+staff.getEmail());
																		}
																		else {
																			System.out.println("Email: N/A");
																		}
																		if(staff.getImage()!=null) {
																			System.out.println("Image: "+staff.getImage());
																		}
																		else {
																			System.out.println("Image: N/A");
																		}
																		if(staff.getPhone()!=null) {
																			System.out.println("Phone: "+staff.getPhone());
																		}
																		else {
																			System.out.println("Phone: N/A");
																		}
																		if(staff.getOffice()!=null) {
																			System.out.println("Office: "+staff.getOffice());
																		}
																		else {
																			System.out.println("Office: N/A");
																		}
																		System.out.print("Office Hours: ");
																		if(staff.getOfficeHours().size()!=0) {
																			for(int j=0;j<staff.getOfficeHours().size();j++) {
																				MeetingPeriod mp = staff.getOfficeHours().get(j);
																				if(mp.getDay()!=null && mp.getTime()!=null && mp.getTime().getStart()!= null && mp.getTime().getEnd()!=null) {
																					System.out.print(mp.getDay()+" "+mp.getTime().getStart()+"-"+mp.getTime().getEnd());
																				}else {
																					if(mp.getDay() == null) {
																						System.out.print("TBA ");
																					}else {
																						System.out.print(mp.getDay()+" ");
																					}
																					if(mp.getTime()!=null) {
																						if(mp.getTime().getStart()==null) {
																							System.out.print("TBA-");	
																						}else {
																							System.out.print(mp.getTime().getStart()+"-");
																						}
																						if(mp.getTime().getEnd()==null) {
																							System.out.print("TBA");	
																						}else {
																							System.out.print(mp.getTime().getEnd());
																						}
																					}
																				}

																				if(j!=staff.getOfficeHours().size()-1) {
																					System.out.print(", ");
																				}
																			}
																			System.out.println();
																		}else {
																			System.out.print("N/A");
																			System.out.println();
																		}
																	}
																}
															}
															if(menuOption.equals("2")) {	
																ArrayList<courseStaff> ta = choiceCourse.getStaffMembers();
																for(int i=1; i<staffSize+1;i++) {
																	if(ta.get(i-1).getType().equals("ta")){
																		System.out.println();
																		System.out.println("TA");
																		courseStaff staff = ta.get(i-1);
																		System.out.println("Name: "+staff.getName().getFirstname()+" "+staff.getName().getLastname());
																		if(staff.getEmail()!=null) {
																			System.out.println("Email: "+staff.getEmail());
																		}
																		else {
																			System.out.println("Email: N/A");
																		}
																		if(staff.getImage()!=null) {
																			System.out.println("Image: "+staff.getImage());
																		}
																		else {
																			System.out.println("Image: N/A");
																		}
																		if(staff.getPhone()!=null) {
																			System.out.println("Phone: "+staff.getPhone());
																		}
																		if(staff.getOffice()!=null) {
																			System.out.println("Office: "+staff.getOffice());
																		}
																		else {
																			System.out.println("Office: N/A");
																		}
																		System.out.print("Office Hours: ");
																		if(staff.getOfficeHours().size()!=0) {
																			for(int j=0;j<staff.getOfficeHours().size();j++) {
																				MeetingPeriod mp = staff.getOfficeHours().get(j);
																				if(mp.getDay()!=null && mp.getTime()!=null && mp.getTime().getStart()!= null && mp.getTime().getEnd()!=null) {
																					System.out.print(mp.getDay()+" "+mp.getTime().getStart()+"-"+mp.getTime().getEnd());
																				}else {
																					if(mp.getDay() == null) {
																						System.out.print("TBA ");
																					}else {
																						System.out.print(mp.getDay()+" ");
																					}
																					if(mp.getTime()!=null) {
																						if(mp.getTime().getStart()==null) {
																							System.out.print("TBA-");	
																						}else {
																							System.out.print(mp.getTime().getStart()+"-");
																						}
																						if(mp.getTime().getEnd()==null) {
																							System.out.print("TBA");	
																						}else {
																							System.out.print(mp.getTime().getEnd());
																						}
																					}
																				}
																				if(j!=staff.getOfficeHours().size()-1) {
																					System.out.print(", ");
																				}
																			}
																			System.out.println();
																		}else {
																			System.out.print("N/A");
																			System.out.println();
																		}
																	}
																}
															}
															if(menuOption.equals("3")) {
																ArrayList<courseStaff> cp = choiceCourse.getStaffMembers();
																for(int i=1; i<staffSize+1;i++) {
																	if(cp.get(i-1).getType().equals("cp")){
																		System.out.println();
																		System.out.println("CP");
																		courseStaff staff = cp.get(i-1);
																		System.out.println("Name: "+staff.getName().getFirstname()+" "+staff.getName().getLastname());
																		if(staff.getEmail()!=null) {
																			System.out.println("Email: "+staff.getEmail());
																		}
																		else {
																			System.out.println("Email: N/A");
																		}
																		if(staff.getImage()!=null) {
																			System.out.println("Image: "+staff.getImage());
																		}
																		else {
																			System.out.println("Image: N/A");
																		}
																		if(staff.getPhone()!=null) {
																			System.out.println("Phone: "+staff.getPhone());
																		}
																		if(staff.getOffice()!=null) {
																			System.out.println("Office: "+staff.getOffice());
																		}
																		else {
																			System.out.println("Office: N/A");
																		}
																		System.out.print("Office Hours: ");
																		if(staff.getOfficeHours().size()!=0) {
																			for(int j=0;j<staff.getOfficeHours().size();j++) {
																				MeetingPeriod mp = staff.getOfficeHours().get(j);
																				if(mp.getDay()!=null && mp.getTime()!=null && mp.getTime().getStart()!= null && mp.getTime().getEnd()!=null) {
																					System.out.print(mp.getDay()+" "+mp.getTime().getStart()+"-"+mp.getTime().getEnd());
																				}else {
																					if(mp.getDay() == null) {
																						System.out.print("TBA ");
																					}else {
																						System.out.print(mp.getDay()+" ");
																					}
																					if(mp.getTime()!=null) {
																						if(mp.getTime().getStart()==null) {
																							System.out.print("TBA-");	
																						}else {
																							System.out.print(mp.getTime().getStart()+"-");
																						}
																						if(mp.getTime().getEnd()==null) {
																							System.out.print("TBA");	
																						}else {
																							System.out.print(mp.getTime().getEnd());
																						}
																					}
																				}
																				if(j!=staff.getOfficeHours().size()-1) {
																					System.out.print(", ");
																				}
																			}
																			System.out.println();
																		}else {
																			System.out.print("N/A");
																			System.out.println();
																		}
																	}
																}
															}
															if(menuOption.equals("4")) {
																ArrayList<courseStaff> grader = choiceCourse.getStaffMembers();
																for(int i=1; i<staffSize+1;i++) {
																	if(grader.get(i-1).getType().equals("grader")){
																		System.out.println();
																		System.out.println("Grader");
																		courseStaff staff = grader.get(i-1);
																		System.out.println("Name: "+staff.getName().getFirstname()+" "+staff.getName().getLastname());
																		if(staff.getEmail()!=null) {
																			System.out.println("Email: "+staff.getEmail());
																		}
																		else {
																			System.out.println("Email: N/A");
																		}
																		if(staff.getImage()!=null) {
																			System.out.println("Image: "+staff.getImage());
																		}
																		else {
																			System.out.println("Image: N/A");
																		}
																		if(staff.getPhone()!=null) {
																			System.out.println("Phone: "+staff.getPhone());
																		}
																		if(staff.getOffice()!=null) {
																			System.out.println("Office: "+staff.getOffice());
																		}

																		System.out.print("Office Hours: ");
																		if(staff.getOfficeHours().size()!=0) {
																			for(int j=0;j<staff.getOfficeHours().size();j++) {
																				MeetingPeriod mp = staff.getOfficeHours().get(j);
																				if(mp.getDay()!=null && mp.getTime()!=null && mp.getTime().getStart()!= null && mp.getTime().getEnd()!=null) {
																					System.out.print(mp.getDay()+" "+mp.getTime().getStart()+"-"+mp.getTime().getEnd());
																				}else {
																					if(mp.getDay() == null) {
																						System.out.print("TBA ");
																					}else {
																						System.out.print(mp.getDay()+" ");
																					}
																					if(mp.getTime()==null) {
																						System.out.print("TBA-TBA");
																					}else {
																						if(mp.getTime().getStart()==null) {
																							System.out.print("TBA-");	
																						}else {
																							System.out.print(mp.getTime().getStart()+"-");
																						}
																						if(mp.getTime().getEnd()==null) {
																							System.out.print("TBA");	
																						}else {
																							System.out.print(mp.getTime().getEnd());
																						}
																					}
																				}
																				if(j!=staff.getOfficeHours().size()-1) {
																					System.out.print(", ");
																				}
																			}
																		}else {
																			System.out.print("N/A");
																		}
																		System.out.println();
																	}
																}
															}

														}catch(NumberFormatException e) {
															System.out.println("That is not a valid option.");
															System.out.println();
														}
													}while(!menuOption.equals("Exit"));
												}
												if(menuOption.equals("2")){
													/*read meeting*/
													do {
														System.out.println();
														System.out.println(choiceDep.getPrefix()+" "+choiceCourse.getNumber()+" "+choiceCourse.getTerm()+" "+choiceCourse.getYear());
														System.out.println("Meeting Information");
														System.out.println("\t"+ "1) Lecture");
														System.out.println("\t"+ "2) Lab");
														System.out.println("\t" + "3) Quiz");
														System.out.println("\t" + "4) Go to "+choiceDep.getPrefix()+" "+choiceCourse.getNumber()+" "+choiceCourse.getTerm()+" "+choiceCourse.getYear()+ " menu");
														System.out.println("\t"+"5) Exit");
														System.out.print("What would you like to do? ");
														menuOption = scan.nextLine();
														if(menuOption.equals("4")) {
															break;
														}	
														if(menuOption.equals("5")) {
															menuOption = "Exit";
															break;
														}
														try {
															if(Integer.parseInt(menuOption)<= 0 || Integer.parseInt(menuOption) > 5) {
																throw new NumberFormatException();
															}
															int meetingSize = choiceCourse.getMeetings().size();
															if(menuOption.equals("1") ){
																ArrayList<Meeting> meeting = choiceCourse.getMeetings();
																for(int i=0; i<meetingSize;i++) {
																	if(meeting.get(i).getType().equals("lecture")){
																		System.out.println();
																		System.out.println(choiceDep.getPrefix()+" "+choiceCourse.getNumber()+" "+choiceCourse.getTerm()+" "+choiceCourse.getYear());
																		Meeting mePe = meeting.get(i);
																		System.out.println("Lecture Meeting Information");
																		System.out.println("Section: "+mePe.getSection());
																		if(mePe.getRoom()!=null) {
																			System.out.println("Room: "+mePe.getRoom());
																		}else {
																			System.out.println("Room: TBA");
																		}
																		System.out.print("Meetings: ");
																		for(int j=0;j<mePe.getMeetingPeriods().size();j++) {
																			MeetingPeriod mp = mePe.getMeetingPeriods().get(j);
																			if(mp.getDay()!=null && mp.getTime()!=null && mp.getTime().getStart()!= null && mp.getTime().getEnd()!=null) {
																				System.out.print(mp.getDay()+" "+mp.getTime().getStart()+"-"+mp.getTime().getEnd());
																			}else {
																				if(mp.getDay() == null) {
																					System.out.print("TBA ");
																				}else {
																					System.out.print(mp.getDay()+" ");
																				}
																				if(mp.getTime()!=null) {
																					if(mp.getTime().getStart()==null) {
																						System.out.print("TBA-");	
																					}else {
																						System.out.print(mp.getTime().getStart()+"-");
																					}
																					if(mp.getTime().getEnd()==null) {
																						System.out.print("TBA");	
																					}else {
																						System.out.print(mp.getTime().getEnd());
																					}
																				}
																			}
																			if(j!=mePe.getMeetingPeriods().size()-1) {
																				System.out.print(", ");
																			}
																		}
																		System.out.println();
																		System.out.print("Assistants: ");
																		if(mePe.getAssistants().size()!=0) {
																			for(int j=0;j<mePe.getAssistants().size();j++) {
																				Assistant assistant = mePe.getAssistants().get(j);
																				System.out.print(choiceCourse.findStaffIDtoName(assistant.getStaffMemberID()));
																				if(j!=mePe.getAssistants().size()-1) {
																					System.out.print(", ");
																				}
																			}	
																		}else {
																			System.out.print("N/A");
																		}
																	}
																}
																System.out.println();
															}
															if(menuOption.equals("2")) {																
																ArrayList<Meeting> meeting = choiceCourse.getMeetings();
																for(int i=1; i<meetingSize+1;i++) {
																	if(meeting.get(i-1).getType().equals("lab")){
																		System.out.println();
																		System.out.println(choiceDep.getPrefix()+" "+choiceCourse.getNumber()+" "+choiceCourse.getTerm()+" "+choiceCourse.getYear());
																		Meeting mePe = meeting.get(i-1);
																		System.out.println("Lab Meeting Information");
																		System.out.println("Section: "+mePe.getSection());
																		if(mePe.getRoom()!=null) {
																			System.out.println("Room: "+mePe.getRoom());
																		}else {
																			System.out.println("Room: TBA");
																		}
																		System.out.print("Meetings: ");
																		for(int j=0;j<mePe.getMeetingPeriods().size();j++) {
																			MeetingPeriod mp = mePe.getMeetingPeriods().get(j);
																			if(mp.getDay()!=null && mp.getTime()!=null && mp.getTime().getStart()!= null && mp.getTime().getEnd()!=null) {
																				System.out.print(mp.getDay()+" "+mp.getTime().getStart()+"-"+mp.getTime().getEnd());
																			}else {
																				if(mp.getDay() == null) {
																					System.out.print("TBA ");
																				}else {
																					System.out.print(mp.getDay()+" ");
																				}
																				if(mp.getTime()!=null) {
																					if(mp.getTime().getStart()==null) {
																						System.out.print("TBA-");	
																					}else {
																						System.out.print(mp.getTime().getStart()+"-");
																					}
																					if(mp.getTime().getEnd()==null) {
																						System.out.print("TBA");	
																					}else {
																						System.out.print(mp.getTime().getEnd());
																					}
																				}
																			}
																			if(j!=mePe.getMeetingPeriods().size()-1) {
																				System.out.print(", ");
																			}
																		}
																		System.out.println();
																		System.out.print("Assistants: ");
																		if(mePe.getAssistants().size()!=0) {
																			for(int j=0;j<mePe.getAssistants().size();j++) {
																				Assistant assistant = mePe.getAssistants().get(j);
																				System.out.print(choiceCourse.findStaffIDtoName(assistant.getStaffMemberID()));
																				if(j!=mePe.getAssistants().size()-1) {
																					System.out.print(", ");
																				}
																			}	
																		}else {
																			System.out.print("N/A");
																		}																
																	}
																}
																System.out.println();
															}
															if(menuOption.equals("3")) {
																ArrayList<Meeting> meeting = choiceCourse.getMeetings();
																for(int i=1; i<meetingSize+1;i++) {
																	if(meeting.get(i-1).getType().equals("quiz")){
																		System.out.println();
																		System.out.println(choiceDep.getPrefix()+" "+choiceCourse.getNumber()+" "+choiceCourse.getTerm()+" "+choiceCourse.getYear());
																		Meeting mePe = meeting.get(i-1);
																		System.out.println("Quiz Meeting Information");
																		System.out.println("Section: "+mePe.getSection());
																		if(mePe.getRoom()!=null) {
																			System.out.println("Room: "+mePe.getRoom());
																		}else {
																			System.out.println("Room: TBA");
																		}
																		System.out.print("Meetings: ");
																		for(int j=0;j<mePe.getMeetingPeriods().size();j++) {
																			MeetingPeriod mp = mePe.getMeetingPeriods().get(j);
																			if(mp.getDay()!=null && mp.getTime()!=null && mp.getTime().getStart()!= null && mp.getTime().getEnd()!=null) {
																				System.out.print(mp.getDay()+" "+mp.getTime().getStart()+"-"+mp.getTime().getEnd());
																			}else {
																				if(mp.getDay() == null) {
																					System.out.print("TBA ");
																				}else {
																					System.out.print(mp.getDay()+" ");
																				}
																				if(mp.getTime()!=null) {
																					if(mp.getTime().getStart()==null) {
																						System.out.print("TBA-");	
																					}else {
																						System.out.print(mp.getTime().getStart()+"-");
																					}
																					if(mp.getTime().getEnd()==null) {
																						System.out.print("TBA");	
																					}else {
																						System.out.print(mp.getTime().getEnd());
																					}
																				}
																			}
																			if(j!=mePe.getMeetingPeriods().size()-1) {
																				System.out.print(", ");
																			}
																		}
																		System.out.println();
																		System.out.print("Assistants: ");
																		if(mePe.getAssistants().size()!=0) {
																			for(int j=0;j<mePe.getAssistants().size();j++) {
																				Assistant assistant = mePe.getAssistants().get(j);
																				System.out.print(choiceCourse.findStaffIDtoName(assistant.getStaffMemberID()));
																				if(j!=mePe.getAssistants().size()-1) {
																					System.out.print(", ");
																				}
																			}	
																		}else {
																			System.out.print("N/A");

																		}																
																	}
																}
																System.out.println();
															}														
														}catch(NumberFormatException e) {
															System.out.println("That is not a valid option.");
															System.out.println();
														}
													}while(!menuOption.equals("Exit"));
												}												
											}catch(NumberFormatException e) {
												System.out.println("That is not a valid option.");
												System.out.println();
											}
										}while(!menuOption.equals("Exit"));
									}catch(NumberFormatException e) {
										System.out.println("That is not a valid option.");
										System.out.println();
									}
								}while(!menuOption.equals("Exit"));
							}catch(NumberFormatException e) {
								System.out.println("That is not a valid option.");
								System.out.println();
							}
						}while(!menuOption.equals("Exit"));
					}catch(NumberFormatException e) {
						System.out.println("That is not a valid option.");
						System.out.println();
					}
				}while(!menuOption.equals("Exit"));

			}catch(NumberFormatException e) {
				System.out.println("That is not a valid option.");
				System.out.println();
			}
		}while(!menuOption.equals("Exit")); 
		System.out.println();
		System.out.println("Thank you for using my program");

	}

}
