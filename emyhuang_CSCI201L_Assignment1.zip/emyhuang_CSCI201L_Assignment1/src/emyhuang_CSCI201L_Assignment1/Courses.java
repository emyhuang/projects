package emyhuang_CSCI201L_Assignment1;

import java.util.ArrayList;

public class Courses {
	private int number;
	private String term;
	private int year;
	private ArrayList<courseStaff> staffMembers = new ArrayList<>();
	private ArrayList<Meeting> meetings = new ArrayList<>();
	
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	public Boolean isValidCourse() {
		if(number == 0 || term==null || year==0) {
			return false;
		}
		if(staffMembers==null) {
			return false;
		}
		if(meetings == null) {
			return false;
		}
		return true;
	}
	public ArrayList<courseStaff> getStaffMembers() {
		return staffMembers;
	}
	public void setStaffMembers(ArrayList<courseStaff> staffMembers) {
		this.staffMembers = staffMembers;
	}
	public ArrayList<Meeting> getMeetings() {
		return meetings;
	}
	public void setMeetings(ArrayList<Meeting> meetings) {
		this.meetings = meetings;
	}
	
	public String findStaffIDtoName(int id) {
		for(int i = 0; i< staffMembers.size(); i++) {
			if(id == staffMembers.get(i).getId()) {
				return staffMembers.get(i).getName().getFirstname()+" "+staffMembers.get(i).getName().getLastname();
			}
		}
		return "Staff ID "+id+" is not found.";
	}
}
