package emyhuang_CSCI201L_Assignment1;

import java.util.ArrayList;

public class Department {
	public String longName;
	public String prefix;
	public ArrayList<Courses> courses = new ArrayList<>();
	
	public String getName() {
		return longName;
	}
	public void setName(String name) {
		this.longName = name;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public ArrayList<Courses> getCourses() {
		return courses;
	}
	public void setCourses(ArrayList<Courses> courses) {
		this.courses = courses;
	}
	
	public Boolean isValidDepartment() {
		if(longName==null || prefix ==null) {
			System.out.println("1111");
			return false;
		}
		if(courses==null) {
			System.out.println("1112");
			return false;
		}
		return true;
	}
	
}
