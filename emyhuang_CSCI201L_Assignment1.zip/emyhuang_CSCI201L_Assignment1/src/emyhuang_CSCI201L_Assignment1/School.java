package emyhuang_CSCI201L_Assignment1;

import java.util.ArrayList;

public class School {
	private String name;
	private ArrayList<Department> departments = new ArrayList<>();
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<Department> getDepartments() {
		return departments;
	}
	
	public Boolean validSchool() {
		if(name==null) {
			return false;
		}
		if(departments == null) {
			return false;
		}
		return true;
	}
	
	
}
