package emyhuang_CSCI201L_Assignment1;

public class Name {
	private String fname;
	private String lname;
	
	public String getLastname() {
		return lname;
	}
	public void setLastname(String lastname) {
		this.lname = lastname;
	}
	public String getFirstname() {
		return fname;
	}
	public void setFirstname(String firstname) {
		this.fname = firstname;
	}
	
	public Boolean isNameValid() {
		if(fname==null || lname==null) {
			return false;
		}
		return true;
	}
}
