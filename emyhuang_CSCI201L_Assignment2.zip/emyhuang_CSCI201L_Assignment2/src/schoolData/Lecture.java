package schoolData;
import java.util.ArrayList;

public class Lecture {
	private String number;
	private String date;
	private String day;
	private ArrayList<Topic> topics = new ArrayList<>();
	
	public String getNumber() {
		return number;
	}
	public String getDate() {
		return date;
	}
	public String getDay() {
		return day;
	}
	public ArrayList<Topic> getTopics() {
		return topics;
	}
}
