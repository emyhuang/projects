package schoolData;

import java.util.ArrayList;

import emyhuang_CSCI201L_Assignment1.Department;

public class School {
	private String name;
	private String image;
	private ArrayList<Department> departments = new ArrayList<>();
	
	public String getImage() {
		return image;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<Department> getDepartments() {
		return departments;
	}
	
}

