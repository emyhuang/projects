package schoolData;

import java.util.ArrayList;

public class Deliverable {
	private String number;
	private String dueDate;
	private String title;
	private String gradePercentage;
	private ArrayList<File> files = new ArrayList<>();
	
	public String getNumber() {
		return number;
	}
	public String getDueDate() {
		return dueDate;
	}
	public String getTitle() {
		return title;
	}
	public String getGradePercentage() {
		return gradePercentage;
	}
	public ArrayList<File> getFiles() {
		return files;
	}
}
