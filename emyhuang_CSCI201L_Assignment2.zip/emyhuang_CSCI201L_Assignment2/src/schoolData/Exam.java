package schoolData;

import java.util.ArrayList;

public class Exam {
	private String semester;
	private String year;
	private ArrayList<Test> tests = new ArrayList<>();
	
	public String getSemester() {
		return semester;
	}
	public String getYear() {
		return year;
	}
	public ArrayList<Test> getTests() {
		return tests;
	}
}
