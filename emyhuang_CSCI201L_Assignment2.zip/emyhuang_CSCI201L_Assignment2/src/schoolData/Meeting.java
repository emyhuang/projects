package schoolData;

import java.util.ArrayList;

public class Meeting {
	private String type;
	private String section;
	private String room;
	private ArrayList<MeetingPeriod> meetingPeriods = new ArrayList<>();
	private ArrayList<Assistant> assistants = new ArrayList<>();
	
	public ArrayList<MeetingPeriod> getMeetingPeriods() {
		return meetingPeriods;
	}

	public ArrayList<Assistant> getAssistants() {
		return assistants;
	}

	public String getType() {
		return type;
	}

	public String getSection() {
		return section;
	}
	public String getRoom() {
		return room;
	}


}

