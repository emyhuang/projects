package schoolData;

public class Textbook {
	private String number;
	private String author;
	private String title;
	private String publisher;
	private String year;
	private String isbn;
	
	public String getNumber() {
		return number;
	}
	public String getAuthor() {
		return author;
	}
	public String getTitle() {
		return title;
	}
	public String getPublisher() {
		return publisher;
	}
	public String getYear() {
		return year;
	}
	public String getIsbn() {
		return isbn;
	}
	
}
