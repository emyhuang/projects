package schoolData;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;


public class Parser {
	private ArrayList<School> schools = new ArrayList<>();
	
	public ArrayList<School> getSchools(){
		return schools;
	}

	public void setSchools(ArrayList<School> schools) {
		this.schools = schools;
	}
		
}