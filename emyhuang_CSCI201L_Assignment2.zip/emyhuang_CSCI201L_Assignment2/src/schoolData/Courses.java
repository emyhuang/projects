package schoolData;

import java.util.ArrayList;

import emyhuang_CSCI201L_Assignment1.Meeting;
import emyhuang_CSCI201L_Assignment1.courseStaff;

public class Courses {
	private String number;
	private String title;
	private int units;
	private String term;
	private int year;
	private ArrayList<CourseStaff> staffMembers = new ArrayList<>();
	private ArrayList<Meeting> meetings = new ArrayList<>();
	private Syllabus syllabus;
	private Schedule schedule;
	private ArrayList<Assignment> assignments = new ArrayList<>();
	private ArrayList<Exam> exams = new ArrayList<>();
	
	public ArrayList<Assignment> getAssignments() {
		return assignments;
	}
	public ArrayList<Exam> getExams() {
		return exams;
	}
	
	public Syllabus getSyllabus() {
		return syllabus;
	}
	public Schedule getSchedule() {
		return schedule;
	}
	public int getUnits() {
		return units;
	}
	public String getTitle() {
		return title;
	}
	public String getNumber() {
		return number;
	}

	public String getTerm() {
		return term;
	}

	public int getYear() {
		return year;
	}
	
	public ArrayList<CourseStaff> getStaffMembers() {
		return staffMembers;
	}

	public ArrayList<Meeting> getMeetings() {
		return meetings;
	}
	
	/*
	 * Argument int id is the staff id number
	 * returns String of name belonging to the id.
	 */
	public String findStaffIDtoName(int id) {
		for(int i = 0; i< staffMembers.size(); i++) {
			if(id == staffMembers.get(i).getId()) {
				return staffMembers.get(i).getName().getFirstname()+" "+staffMembers.get(i).getName().getLastname();
			}
		}
		return "Staff ID "+id+" is not found.";
	}
	
	/*
	 * Argument in id is staff id number
	 * returns CourseStaff belonging to the id
	 */
	public CourseStaff findStaff(int id) {
		for(int i = 0; i< staffMembers.size(); i++) {
			if(id == staffMembers.get(i).getId()) {
				return staffMembers.get(i);
			}
		}
		return null;
	}
}

