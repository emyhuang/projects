package schoolData;

import java.util.ArrayList;

import emyhuang_CSCI201L_Assignment1.MeetingPeriod;
import emyhuang_CSCI201L_Assignment1.Name;

public class CourseStaff {
	private String type;
	private int id;
	private Name name;
	private String email;
	private String image;
	private String phone;
	private String office;
	private ArrayList<MeetingPeriod> officeHours = new ArrayList<>();
	
	public String getOffice() {
		return office;
	}
	
	public String getType() {
		return type;
	}

	public int getId() {
		return id;
	}

	public Name getName() {
		return name;
	}
	
	public String getEmail() {
		return email;
	}

	public String getImage() {
		return image;
	}

	public String getPhone() {
		return phone;
	}

	public ArrayList<MeetingPeriod> getOfficeHours() {
		return officeHours;
	}


}
