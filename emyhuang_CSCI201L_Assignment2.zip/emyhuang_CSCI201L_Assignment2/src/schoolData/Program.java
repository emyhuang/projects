package schoolData;

import java.util.ArrayList;

public class Program {
	private ArrayList<File> files = new ArrayList<>();

	public ArrayList<File> getFiles() {
		return files;
	}
	
	
}
