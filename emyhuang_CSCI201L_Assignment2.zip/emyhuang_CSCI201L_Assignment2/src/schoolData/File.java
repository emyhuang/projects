package schoolData;

public class File {
	private String number;
	private String title;
	private String url;
	
	public String getNumber() {
		return number;
	}
	public String getTitle() {
		return title;
	}
	public String getUrl() {
		return url;
	}
}
