package schoolData;

import java.util.ArrayList;

public class Topic {
	private String number;
	private String title;
	private String url;
	private String chapter;
	private ArrayList<Program> programs = new ArrayList<>();
	
	public String getNumber() {
		return number;
	}
	public String getTitle() {
		return title;
	}
	public String getUrl() {
		return url;
	}
	public String getChapter() {
		return chapter;
	}
	public ArrayList<Program> getPrograms() {
		return programs;
	}
}
