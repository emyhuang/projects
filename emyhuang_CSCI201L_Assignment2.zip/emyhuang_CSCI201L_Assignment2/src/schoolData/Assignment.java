package schoolData;

import java.util.ArrayList;

public class Assignment {
	private String number;
	private String assignedDate;
	private String dueDate;
	private String title;
	private String url;
	private ArrayList<File> files = new ArrayList<>();
	private String gradePercentage;
	private ArrayList<File> gradingCriteriaFiles = new ArrayList<>();
	private ArrayList<File> solutionFiles = new ArrayList<>();
	private ArrayList<Deliverable> deliverables = new ArrayList<>();
	
	public ArrayList<File> getGradingCriteriaFiles() {
		return gradingCriteriaFiles;
	}
	public ArrayList<File> getSolutionFiles() {
		return solutionFiles;
	}

	
	public ArrayList<Deliverable> getDeliverables() {
		return deliverables;
	}
	public String getNumber() {
		return number;
	}
	public String getAssignedDate() {
		return assignedDate;
	}
	public String getDueDate() {
		return dueDate;
	}
	public String getTitle() {
		return title;
	}
	public String getUrl() {
		return url;
	}
	public ArrayList<File> getFiles() {
		return files;
	}
	public String getGradePercentage() {
		return gradePercentage;
	}
}
