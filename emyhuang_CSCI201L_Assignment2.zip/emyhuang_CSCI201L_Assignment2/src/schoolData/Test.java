package schoolData;

import java.util.ArrayList;

public class Test {
	private String semester;
	private ArrayList<File> files = new ArrayList<>();
	
	public String getSemester() {
		return semester;
	}
	public ArrayList<File> getFiles() {
		return files;
	}
}
