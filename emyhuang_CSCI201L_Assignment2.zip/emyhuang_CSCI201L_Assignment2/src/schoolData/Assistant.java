package schoolData;

public class Assistant {
	private int staffMemberID;

	public int getStaffMemberID() {
		return staffMemberID;
	}

	public void setStaffMemberID(int staffMemberID) {
		this.staffMemberID = staffMemberID;
	}
}
