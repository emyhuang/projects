package schoolData;

import java.util.ArrayList;


public class Schedule {
	private ArrayList<Textbook> textbooks = new ArrayList<>();
	private ArrayList<Week> weeks = new ArrayList<>();

	
	public ArrayList<Textbook> getTextbooks() {
		return textbooks;
	}
	public ArrayList<Week> getWeeks() {
		return weeks;
	}

}
