package schoolData;

import java.util.ArrayList;

public class Week {
	private String week;
	private ArrayList<Lab> labs = new ArrayList<>();
	private ArrayList<Lecture> lectures = new ArrayList<>();
	
	public String getWeek() {
		return week;
	}
	public ArrayList<Lab> getLabs() {
		return labs;
	}
	public ArrayList<Lecture> getLectures() {
		return lectures;
	}
}
