README.MD

Emy Huang
8420194561
emyhuang@usc.edu

To run program:
Must be in directory Project1/bin

java main.SearchMap ../input.txt output.txt


All ant commands are working.