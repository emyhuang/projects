package main;
import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


import org.junit.Test;
public  class SearchMapTest {
	SearchMap map;
	
	/*
	 * Test Search map
	 */
	public SearchMapTest() {
		map = new SearchMap("input.txt", "outputfile.txt");
	}
	
	@Test
	public void testWriteOutToFile() {
		map.writeOutToFile();
		File tmpfile = new File("outputfile.txt");
		assertTrue(tmpfile.exists());

	}
		
}
