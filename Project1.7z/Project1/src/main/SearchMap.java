package main;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

public class SearchMap {
	private FlightMap map;
	private String outputfile;
	
	/*
	 * Constructor creates map
	 * @param str is inputfile
	 * @param str2 is outputfile
	 */
	public SearchMap(String str, String str2){
		map = new FlightMap(str);
		outputfile = str2;
		map.makeItinerary();
	}
	
	public static void main(String[] arg) {
		SearchMap sm = new SearchMap(arg[0], arg[1]);
		sm.writeOutToFile();
	}
	
	/*
	 * Write map with destinations out to file
	 */
	public void writeOutToFile() {
		try {
			FileWriter fw = new FileWriter(outputfile);
			PrintWriter pw = new PrintWriter(fw);
			pw.printf("%-20s%-20s%-20s\n", "Destination", "Flight Route from P", "Total Cost");
			pw.println();
			
			for(Map.Entry<String, Node> entry: map.getMap().entrySet()) {
				pw.printf("%-20s%-20s%-20s\n", entry.getKey(), entry.getValue().getKey(), entry.getValue().getValue());
				pw.println();
			}
			
			pw.close();
			fw.close();
		}catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
	}
	
}
	

