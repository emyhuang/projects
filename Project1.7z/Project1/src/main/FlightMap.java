package main;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;

/*
 * Creates map of destinations from origin
 * @Author Emy Huang
 * Uses Node Class
 */
public class FlightMap {
	private Node node;
	private Map<String, Node> destMap;
	private Map<String, List<Node>> directFlight;
	private String origin;
	
	public FlightMap() {
		destMap = null;
		
	}
	
	/*
	 * @param String mapFile is the input file name
	 * Reads in input file to create initial pairing of destinations and price
	 */
	public FlightMap(String mapFile) {
		directFlight = new HashMap<>();
		String line;
		try {
			FileReader fileRead = new FileReader(mapFile);
		
			BufferedReader buffReader = new BufferedReader(fileRead);
			origin = buffReader.readLine();
			while((line=buffReader.readLine()) != null) {
				//System.out.println(line);
				Scanner scan = new Scanner(line);
				
				//'place' is origin, key is dest, value is price
				String place = scan.next();
				String key = scan.next();
				String value = scan.next();
				
				Node newNode = new Node(key, Integer.parseInt(value));
				
				//check if origin exists
				if(directFlight.containsKey(place)) {
					//get list and insert
					directFlight.get(place).add(newNode);
				}else {
					//make new mapping
					ArrayList<Node> newList = new ArrayList<>();
					newList.add(newNode);
					directFlight.put(place, newList);
				}
				scan.close();
			}
			buffReader.close();
			
		}
		catch(FileNotFoundException fx) {
			System.out.println("file not found: " + fx.getMessage());
		}
		catch(IOException ioe) {
			System.out.println("ioe message: " + ioe.getMessage());
		}
		
	}
	
	/*
	 * Creates map of destinations from origin and calculates the costs
	 */
	public void makeItinerary() {
		//make paths from paths
		Queue<String> queue = new LinkedList<>();
		
		destMap = new HashMap<>();
		ArrayList<Node> list = (ArrayList<Node>) directFlight.get(origin);
		for(int i = 0; i < list.size(); i++) {		
			String line = origin + ", " + list.get(i).getKey();
			queue.add(list.get(i).getKey());
			int cost = list.get(i).getValue();
			Node node = new Node(line, cost );
			destMap.put(list.get(i).getKey(), node);	
		}
		
		//find destinations from destinations 
	
		while(!queue.isEmpty()) {
			String topOfQueue = queue.remove();
			//list of nodes next place has
			ArrayList<Node> destList = (ArrayList<Node>) directFlight.get(topOfQueue);
			if( destList !=null) {
				for(int i=0; i < destList.size(); i++) {
					//check next destination
					if(!destMap.containsKey(destList.get(i).getKey())){
						String destpath = destMap.get(topOfQueue).getKey() +", "+ destList.get(i).getKey();
						int cost = destMap.get(topOfQueue).getValue() + destList.get(i).getValue();
						Node nNode = new Node(destpath, cost);
						destMap.put(destList.get(i).getKey(), nNode);
						queue.add(destList.get(i).getKey());
					}

				}
			}
		}		
	}
	
	/*
	 * Return map of paths to destinations
	 * @return Map<String, Node>
	 */
	public Map<String, Node> getMap(){
		return destMap;
	}
	
}
