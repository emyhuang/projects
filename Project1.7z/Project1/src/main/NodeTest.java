package main;
import static org.junit.Assert.*;

import org.junit.Test;

public class NodeTest {

	
	@Test
	public void testGetKey(){
		Node node = new Node("Z", 1);
		assertEquals("Z", node.getKey());
	}
	
	@Test
	public void testGetValue() {
		Node node = new Node("Z", 1);
		assertEquals(1, node.getValue());
	}
	
	@Test
	public void testSetKey() {
		Node node = new Node("Z", 1);
		node.setKey("T");
		assertEquals("T",node.getKey());
	}
	
	@Test
	public void testSetValue() {
		Node node = new Node("Z", 1);
		node.setValue(400);
		assertEquals(400, node.getValue());
	}
}
