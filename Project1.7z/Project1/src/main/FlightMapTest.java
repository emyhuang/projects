package main;
import static org.junit.Assert.*;


import org.junit.Test;
public class FlightMapTest {
	public FlightMap map;

	public FlightMapTest() {
		map = new FlightMap("input.txt");
	}
	
	@Test
	public void testGetMap() {

		map.makeItinerary();
		assertFalse(map.getMap().isEmpty());
	}
	
	@Test
	public void testMakeItinerary() {
		map.makeItinerary();
		assertEquals( 300 , map.getMap().get("R").getValue());
		assertEquals("P, R", map.getMap().get("R").getKey());
		assertEquals("P, W, Y, Z", map.getMap().get("Z").getKey());
		assertEquals(1150, map.getMap().get("Z").getValue());
		assertEquals("P, R, X", map.getMap().get("X").getKey());
		assertEquals(500, map.getMap().get("X").getValue());
		assertEquals("P, W", map.getMap().get("W").getKey());
		assertEquals(200, map.getMap().get("W").getValue());
		assertEquals("P, W, S", map.getMap().get("S").getKey());
		assertEquals(450, map.getMap().get("S").getValue());
		assertEquals("P, W, S, T", map.getMap().get("T").getKey());
		assertEquals(750, map.getMap().get("T").getValue());
		assertEquals("P, W, Y", map.getMap().get("Y").getKey());
		assertEquals(700, map.getMap().get("Y").getValue());
	}
}
