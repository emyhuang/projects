package main;

/*
 * 
 * @author Emy Huang
 * Node Class to hold data for map:
 * key is a string of the path to a destination
 * value is the cost of the path
 */
public class Node {
	private String key;
	private int value;
	
	/*
	 * Constructor
	 */
	public Node() {
		key = "0";
		value = 0;
	}
	
	/*
	 * K is String
	 * v is integer
	 * @param k is key
	 * @param v is value
	 */
	public Node(String k, int v) {
		key = k;
		value = v;
	}
	
	/*
	 * Return key which is type String
	 * @return String of key
	 */
	public String getKey() {
		return key;
	}
	
	/*
	 * Return value which is type integer
	 * @return value is integer
	 */
	public int getValue() {
		return value;
	}
	
	/*
	 * Set value which is type integer
	 * @param integer value
	 */
	public void setValue(int v) {
		value = v;
	}
	
	/*
	 * Set key which is type String
	 * @param Key is String
	 */
	public void setKey(String k) {
		key = k;
	}
}
